import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Bush here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bush extends Actor 
{
    private GreenfootImage bushONE = new GreenfootImage("bushONE.png");
    private GreenfootImage bushTWO = new GreenfootImage("bushTWO.png");
    private int IMG = Greenfoot.getRandomNumber(2500);
    public void act()
    {
        imgCNG();
    }
    public void imgCNG()
    {
        if(IMG <= 2400)
        {
            setImage("bushONE.png");
            IMG = IMG + 1;
        }
        else if(IMG > 2400 & IMG <= 2500)
        {
           setImage("bushTWO.png"); 
           IMG = IMG + 1;
        }
        else if(IMG > 2500)
        {
            IMG = 0;
        }
    }
}
