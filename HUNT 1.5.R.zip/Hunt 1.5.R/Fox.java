import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Fox here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fox extends Actor
{
    public int tck = 0; //Var to track act ticks
    public Fox()
    {
        GreenfootImage foxD1 = new GreenfootImage("0.png");
        foxD1.scale(foxD1.getWidth() + 16, foxD1.getHeight() + 16);
        setImage(foxD1);
    }
    public void act()
    {
        imgLOPD();
    }
    public void imgLOPD()
    {
        //Make the images
        GreenfootImage foxD1 = new GreenfootImage("0.png");
        foxD1.scale(foxD1.getWidth() + 16, foxD1.getHeight() + 16);
        GreenfootImage foxD2 = new GreenfootImage("1.png");
        foxD2.scale(foxD2.getWidth() + 16, foxD2.getHeight() + 16);
        GreenfootImage foxD3 = new GreenfootImage("2.png");
        foxD3.scale(foxD3.getWidth() + 16, foxD3.getHeight() + 16);
        //Start the loop
        if(tck < 20)
        {
            setImage(foxD1);
            tck = tck + 1;
        }
        else if(tck < 40)
        {
            setImage(foxD2);
            tck = tck + 1;
        }
        else if(tck < 60)
        {
            setImage(foxD3);
            tck = tck + 1;
        }
        else if(tck >= 60)
        {
            setImage(foxD1);
            tck = 0;
        }
    }
}
