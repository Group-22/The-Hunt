import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Forest extends World
{
    public Forest()
    {    
        super(400, 568, 1); 
        placeBushes();
    }
    public void placeBushes()
    {
        placeOther();
        placeBot();
        placeTop();
        placeMid();
        placePer();
    }
    public void placeOther()
    {
        addObject(new House(), 200, 224);
        addObject(new Hole(), 96, 72);
        addObject(new Hole(), 305, 72);
        addObject(new Hole(), 200, 536);
    }
    //Bellow we establish where to place bushes in seperate sections
    public void placePer()
    {
        for (int i = 0; i <= 400; i = i + 16)
        {
            addObject(new Bush(), i, 0);
        }
        for (int j = 0; j <= 560; j = j + 16)
        {
            addObject(new Bush(), 0, j);
        }
        for (int jj = 0; jj <= 560; jj = jj + 16)
        {
            addObject(new Bush(), 400, jj);
        }
        for (int T = 0; T <= 80; T = T + 16)
        {
            addObject(new Bush(), 200, T);
        }    
        for (int TT = 0; TT <= 80 ; TT = TT + 16)
        {
            addObject(new Bush(), 201, TT);
        }
        for (int ii = 0; ii <= 400; ii = ii + 16)
        {
            addObject(new Bush(), ii, 568);
        }
    }
    public void placeTop()
    {
        //Left bushes
        addObject(new Bush(), 64, 64);
        addObject(new Bush(), 128, 64);
        addObject(new Bush(), 64, 80);
        addObject(new Bush(), 128, 80);
        //Right bushes
        addObject(new Bush(), 273, 64);
        addObject(new Bush(), 336, 64);
        addObject(new Bush(), 273, 80);
        addObject(new Bush(), 336, 80);
    }
    public void placeMid()
    {
        for (int MTLL = 144; MTLL <= 176; MTLL = MTLL + 16 )
        {
            for (int MTL = 64; MTL <= 96 ; MTL = MTL + 16)
            {
                addObject(new Bush(), MTL , MTLL);
            }
        }
        for (int MTRR = 144; MTRR <= 176; MTRR = MTRR + 16 )
        {
            for (int MTR = 304; MTR <= 336 ; MTR = MTR + 16)
            {
                addObject(new Bush(), MTR , MTRR);
            }
        }
        for (int MH = 168; MH <= 232 ; MH = MH + 16)
        {
            addObject(new Bush(), MH , 144);
        } 
        for (int ML = 240; ML <= 288 ; ML = ML + 16)
        {
            addObject(new Bush(), 96 , ML);
        } 
        for (int MM = 96; MM <= 160 ; MM = MM + 16)
        {
            addObject(new Bush(), MM , 304);
        }
        for (int MR = 240; MR <= 288 ; MR = MR + 16)
        {
            addObject(new Bush(), 304 , MR);
        } 
        for (int MM = 240; MM <= 304 ; MM = MM + 16)
        {
            addObject(new Bush(), MM , 304);
        } 
        for (int MTMM = 240; MTMM <= 304; MTMM = MTMM + 16 )
        {
            for (int MTM = 16; MTM <= 32 ; MTM = MTM + 16)
            {
                addObject(new Bush(), MTM , MTMM);
            }
        }
        for (int MTMM = 240; MTMM <= 304; MTMM = MTMM + 16 )
        {
            for (int MTM = 368; MTM <= 400 ; MTM = MTM + 16)
            {
                addObject(new Bush(), MTM , MTMM);
            }
        }
    }
    public void placeBot()
    {
        //Middle bushes
        for (int B = 488; B <= 504 ; B = B + 16)
        {
            addObject(new Bush(), 200, B);
        }    
        for (int BB = 488; BB <= 504 ; BB = BB + 16)
        {
            addObject(new Bush(), 201, BB);
        }   
        for (int MM = 152; MM <= 256 ; MM = MM + 16)
        {
            addObject(new Bush(), MM , 368);
        }
        for (int MM = 152; MM <= 256 ; MM = MM + 16)
        {
            addObject(new Bush(), MM , 432);
        }
        //Left bushes
        for (int BTL = 64; BTL <= 80 ; BTL = BTL + 16)
        {
            addObject(new Bush(), BTL , 432);
        }
        for (int BTLL = 440; BTLL <= 472; BTLL = BTLL + 16 )
        {
            for (int BTL = 64; BTL <= 80 ; BTL = BTL + 16)
            {
                addObject(new Bush(), BTL , BTLL);
            }
        }
        for (int BL = 64; BL <= 136 ; BL = BL + 16)
        {
            addObject(new Bush(), BL , 488);
        }
        for (int BLL = 64; BLL <= 136 ; BLL = BLL + 16)
        {
            addObject(new Bush(), BLL , 504);
        } 
        for (int LM = 64; LM <= 80 ; LM = LM + 16)
        {
            addObject(new Bush(), LM , 368);
        }
        //Right bushes
        for (int BTR = 320; BTR <= 336 ; BTR = BTR + 16)
        {
            addObject(new Bush(), BTR , 432);
        }
        for (int BTLL = 440; BTLL <= 472; BTLL = BTLL + 16 )
        {
            for (int BTL = 320; BTL <= 336 ; BTL = BTL + 16)
            {
                addObject(new Bush(), BTL , BTLL);
            }
        }     
        for (int BR = 336; BR >= 265 ; BR = BR - 16)
        {
            addObject(new Bush(), BR , 488);
        }
        for (int BRR = 336; BRR >= 265 ; BRR = BRR - 16)
        {
            addObject(new Bush(), BRR , 504);
        }   
        for (int LM = 320; LM <= 336 ; LM = LM + 16)
        {
            addObject(new Bush(), LM , 368);
        }
    }
}
