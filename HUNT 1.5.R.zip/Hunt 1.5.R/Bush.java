import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Bush here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bush extends Actor 
{
    private GreenfootImage bushONE = new GreenfootImage("bushONE.png");
    public void act()
    {
        setImage("bushONE.png");
    }
}
