import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Hunter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hunter extends AI
{
    public void act()
    {
        topCX();
        midCX();
        botCX();
        move(1);
    }
  } 