import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Fox here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fox extends Actor
{
    // public int tck = 0; //Var to track act ticks
    // public int chc = 1;
    // public int R = 0;
    // public int L = 180;
    // public int U = 270; 
    // public int D = 90;
    // public int dir = 1;
    // public Fox()
    // {
        
    // }
    // public void act()
    // {
        // check();
        // topCX();
        // midCX();
        // botCX();
        // move(1);
    // }
    // public void imgLOPD()
    // {
        
    // }
    // public void imgLOPU()
    // { 
        
    // }
    // public void imgLOPL()
    // {
        
    // }
    // public void imgLOPR()
    // {
        
    // }
    // public void check()
    // {
        // if(Greenfoot.getKey() == "up")
        // {
            // chc = 1;
            
        // }
        // else if(Greenfoot.getKey() == "down")
        // {
            // chc = 3;
        // }
        // else if(Greenfoot.getKey() == "left")
        // {
            // chc = 4;
        // }
        // else if(Greenfoot.getKey() == "right")
        // {
            // chc = 2;
        // }
    // }
    // public void topCX()
    // {
        // if(getX() == 32 & getY() == 32)
        // {
            // if(dir == 1)
            // {
                // setRotation(R);
                // dir = 2;
            // }
            // else if(dir == 4)
            // {
                // setRotation(D);
                // dir = 3;
            // }
        // }
        // else if(getX() == 96 & getY() == 32)
        // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }   
            // }
        // }
        // else if(getX() == 160 & getY() == 32)
        // {
             // if(dir == 1)
             // {
                 // setRotation(L);
                 // dir = 4;
             // }
             // else if(dir == 2)
             // {
                 // setRotation(D);
                 // dir = 3;
             // }
        // }
         // else if(getX() == 240 & getY() == 32)
         // {
             // if(dir == 1)
             // {
                 // setRotation(R);
                 // dir = 2;
             // }
             // else if(dir == 4)
             // {
                 // setRotation(D);
                 // dir = 3;
             // }
         // }
         // else if(getX() == 304 & getY() == 32)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }   
            // }       
         // }
         // else if(getX() == 368 & getY() == 32)
         // {
             // if(dir == 1)
             // {
                 // setRotation(L);
                 // dir = 4;
             // }
             // else if(dir == 2)
             // {
                 // setRotation(D);
                 // dir = 3;
             // }
         // }
         // else if(getX() == 32 & getY() == 112)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 3)
            // {
                // if(chc == 0)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
         // }
         // else if(getX() == 96 & getY() == 112)
         // {
                // if(dir == 2)
                // {
                    // if(chc == 0)
                    // {
                        // setRotation(U);
                        // dir = 1;
                    // }
                    // else if(chc == 1)
                    // {
                        // setRotation(R);
                        // dir = 2;
                    // }
                // }  
                // else if(dir == 3)
                // {
                    // if(chc == 0)
                    // {
                        // setRotation(L);
                        // dir = 4;
                    // }
                    // else if(chc == 1)
                    // {
                        // setRotation(R);
                        // dir = 2;
                    // }
                // }
                // else if(dir == 4)
                // {
                    // if(chc == 0)
                    // {
                        // setRotation(U);
                        // dir = 1;
                    // }
                    // else if(chc == 1)
                    // {
                        // setRotation(L);
                        // dir = 4;
                    // }
                // }
         // }
         // else if(getX() == 128 & getY() == 112)
         // {
                // if(dir == 1)
                // {
                    // if(chc == 0)
                    // {
                        // setRotation(L);
                        // dir = 4;
                    // }
                    // else if(chc == 1)
                    // {
                        // setRotation(R);
                        // dir = 2;
                    // }
                // }  
                // else if(dir == 2)
                // {
                    // if(chc == 0)
                    // {
                        // setRotation(D);
                        // dir = 3;
                    // }
                    // else if(chc == 1)
                    // {
                        // setRotation(R);
                        // dir = 2;
                    // }
                // }
                // else if(dir == 4)
                // {
                    // if(chc == 0)
                    // {
                        // setRotation(D);
                        // dir = 3;
                    // }
                    // else if(chc == 1)
                    // {
                        // setRotation(L);
                        // dir = 4;
                    // }
                // }
         // }
         // else if(getX() == 160 & getY() == 112)
         // {
            // if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 3)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
            // }
         // }
         // else if(getX() == 240 & getY() == 112)
         // {
            // if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 3)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
            // }       
         // }
         // else if(getX() == 272 & getY() == 112)
         // {
                // if(dir == 1)
                // {
                    // if(chc == 0)
                    // {
                        // setRotation(L);
                        // dir = 4;
                    // }
                    // else if(chc == 1)
                    // {
                        // setRotation(R);
                        // dir = 2;
                    // }
                // }  
                // else if(dir == 2)
                // {
                    // if(chc == 0)
                    // {
                        // setRotation(D);
                        // dir = 3;
                    // }
                    // else if(chc == 1)
                    // {
                        // setRotation(R);
                        // dir = 2;
                    // }
                // }
                // else if(dir == 4)
                // {
                    // if(chc == 0)
                    // {
                        // setRotation(D);
                        // dir = 3;
                    // }
                    // if(chc == 1)
                    // {
                        // setRotation(L);
                        // dir = 4;
                    // }
                // }
         // }
         // else if(getX() == 304 & getY() == 112)
         // {
            // if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }  
            // else if(dir == 3)
            // {
                 // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
            // }
         // }
         // else if(getX() == 368 & getY() == 112)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
            // }
            // else if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
            // else if(dir == 3)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
         // }
    // }
    // public void midCX()
    // {
         // if(getX() == 128 & getY() == 176)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 3)
            // {
                // if(chc == 0)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
         // }
         // else if(getX() == 272 & getY() == 176)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
            // }
            // else if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
            // else if(dir == 3)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
         // }
         // else if(getX() == 32 & getY() == 208)
         // {
            // if(dir == 3)
            // {
                // setRotation(R);
                // dir = 2;
            // }
            // else if(dir == 4)
            // {
                // setRotation(U);
                // dir = 1;
            // }
         // }
         // else if(getX() == 64 & getY() == 208)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
            // }
            // else if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
                // if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
         // }
         // else if(getX() == 128 & getY() == 208)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
            // }
            // else if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
            // else if(dir == 3)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
         // }
         // else if(getX() == 272 & getY() == 208)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(U);
                    // dir = 1;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
            // else if(dir == 3)
            // {
                // if(chc == 0)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
         // }
         // else if(getX() == 336 & getY() == 208)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
            // }
            // else if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
         // }
         // else if(getX() == 368 & getY() == 208)
         // {
            // if(dir == 3)
            // {
                // setRotation(L);
                // dir = 4;
            // }
            // else if(dir == 2)
            // {
                // setRotation(U);
                // dir = 1;
            // }
         // }
         // else if(getX() == 128 & getY() == 272)
         // {
            // if(dir == 3)
            // {
                // setRotation(R);
                // dir = 2;
            // }
            // else if(dir == 4)
            // {
                // setRotation(U);
                // dir = 1;
            // }
         // }
         // else if(getX() == 272 & getY() == 272)
         // {
            // if(dir == 3)
            // {
                // setRotation(L);
                // dir = 4;
            // }
            // else if(dir == 2)
            // {
                // setRotation(U);
                // dir = 1;
            // }
         // }
         // else if(getX() == 200 & getY() == 272)
         // {
            // if(dir == 1)
            // {
                // if(chc == 0)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
            // }
            // else if(dir == 2)
            // {
                // if(chc == 0)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(R);
                    // dir = 2;
                // }
            // }
            // else if(dir == 4)
            // {
                // if(chc == 0)
                // {
                    // setRotation(L);
                    // dir = 4;
                // }
                // else if(chc == 1)
                // {
                    // setRotation(D);
                    // dir = 3;
                // }
            // }
         // }
    // }
    // public void botCX()
    // {
         
    // }
}
