import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Cherry here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cherry extends Berry  
{
    //call this in fox and make an if statement that says if eaten == true, speed up the foxes movement.
    public boolean cherryEaten() {
       boolean eaten = false;
        if (isTouching(Fox.class)) {
           getWorld().removeObject(this);
           eaten = true;
       }
       return eaten;
    }
}
