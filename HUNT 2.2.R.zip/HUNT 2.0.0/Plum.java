import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Plum here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Plum extends Berry 
{
   //call this in fox and make an if statement the says if plumCount == 6, exit game.
   public int plumCount = 0;
   public int plumsEaten() {
       if (isTouching(Fox.class)) {
           plumCount++;
           getWorld().removeObject(this);
       }
       return plumCount;
   }
}
