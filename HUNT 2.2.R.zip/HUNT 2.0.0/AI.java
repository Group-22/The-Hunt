import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * 
 * 
 * Not Complete
 * 
 */
public class AI extends Actor 
{
    public int dir = 1;
    public int R = 0;
    public int L = 180;
    public int U = 270; 
    public int D = 90;
    public void topCX()
    {
        int rnd = Greenfoot.getRandomNumber(2);
        if(getX() == 32 & getY() == 32)
        {
            if(dir == 1)
            {
                setRotation(R);
                dir = 2;
            }
            else if(dir == 4)
            {
                setRotation(D);
                dir = 3;
            }
        }
        else if(getX() == 96 & getY() == 32)
        {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(D);
                    dir = 3;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(D);
                    dir = 3;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }   
            }
        }
        else if(getX() == 160 & getY() == 32)
        {
             if(dir == 1)
             {
                 setRotation(L);
                 dir = 4;
             }
             else if(dir == 2)
             {
                 setRotation(D);
                 dir = 3;
             }
        }
         else if(getX() == 240 & getY() == 32)
         {
             if(dir == 1)
             {
                 setRotation(R);
                 dir = 2;
             }
             else if(dir == 4)
             {
                 setRotation(D);
                 dir = 3;
             }
         }
         else if(getX() == 304 & getY() == 32)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(D);
                    dir = 3;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(D);
                    dir = 3;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }   
            }       
         }
         else if(getX() == 368 & getY() == 32)
         {
             if(dir == 1)
             {
                 setRotation(L);
                 dir = 4;
             }
             else if(dir == 2)
             {
                 setRotation(D);
                 dir = 3;
             }
         }
         else if(getX() == 32 & getY() == 112)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 3)
            {
                if(rnd == 0)
                {
                    setRotation(D);
                    dir = 3;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
         }
         else if(getX() == 96 & getY() == 112)
         {
                if(dir == 2)
                {
                    if(rnd == 0)
                    {
                        setRotation(U);
                        dir = 1;
                    }
                    else if(rnd == 1)
                    {
                        setRotation(R);
                        dir = 2;
                    }
                }  
                else if(dir == 3)
                {
                    if(rnd == 0)
                    {
                        setRotation(L);
                        dir = 4;
                    }
                    else if(rnd == 1)
                    {
                        setRotation(R);
                        dir = 2;
                    }
                }
                else if(dir == 4)
                {
                    if(rnd == 0)
                    {
                        setRotation(U);
                        dir = 1;
                    }
                    else if(rnd == 1)
                    {
                        setRotation(L);
                        dir = 4;
                    }
                }
         }
         else if(getX() == 128 & getY() == 112)
         {
                if(dir == 1)
                {
                    if(rnd == 0)
                    {
                        setRotation(L);
                        dir = 4;
                    }
                    else if(rnd == 1)
                    {
                        setRotation(R);
                        dir = 2;
                    }
                }  
                else if(dir == 2)
                {
                    if(rnd == 0)
                    {
                        setRotation(D);
                        dir = 3;
                    }
                    else if(rnd == 1)
                    {
                        setRotation(R);
                        dir = 2;
                    }
                }
                else if(dir == 4)
                {
                    if(rnd == 0)
                    {
                        setRotation(D);
                        dir = 3;
                    }
                    else if(rnd == 1)
                    {
                        setRotation(L);
                        dir = 4;
                    }
                }
         }
         else if(getX() == 160 & getY() == 112)
         {
            if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 3)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }
            }
         }
         else if(getX() == 240 & getY() == 112)
         {
            if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 3)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }
            }       
         }
         else if(getX() == 272 & getY() == 112)
         {
                if(dir == 1)
                {
                    if(rnd == 0)
                    {
                        setRotation(L);
                        dir = 4;
                    }
                    else if(rnd == 1)
                    {
                        setRotation(R);
                        dir = 2;
                    }
                }  
                else if(dir == 2)
                {
                    if(rnd == 0)
                    {
                        setRotation(D);
                        dir = 3;
                    }
                    else if(rnd == 1)
                    {
                        setRotation(R);
                        dir = 2;
                    }
                }
                else if(dir == 4)
                {
                    if(rnd == 0)
                    {
                        setRotation(D);
                        dir = 3;
                    }
                    if(rnd == 1)
                    {
                        setRotation(L);
                        dir = 4;
                    }
                }
         }
         else if(getX() == 304 & getY() == 112)
         {
            if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }  
            else if(dir == 3)
            {
                 if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }
            }
         }
         else if(getX() == 368 & getY() == 112)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }
            }
            else if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
            else if(dir == 3)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
         }
    }
    public void midCX()
    {
         int rnd = Greenfoot.getRandomNumber(2);
         if(getX() == 128 & getY() == 176)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 3)
            {
                if(rnd == 0)
                {
                    setRotation(R);
                    dir = 2;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
         }
         else if(getX() == 272 & getY() == 176)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }
            }
            else if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
            else if(dir == 3)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
         }
         else if(getX() == 32 & getY() == 208)
         {
            if(dir == 3)
            {
                setRotation(R);
                dir = 2;
            }
            else if(dir == 4)
            {
                setRotation(U);
                dir = 1;
            }
         }
         else if(getX() == 64 & getY() == 208)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(R);
                    dir = 2;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }
            }
            else if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(D);
                    dir = 3;
                }
                if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
         }
         else if(getX() == 128 & getY() == 208)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }
            }
            else if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
            else if(dir == 3)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
         }
         else if(getX() == 272 & getY() == 208)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(U);
                    dir = 1;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
            else if(dir == 3)
            {
                if(rnd == 0)
                {
                    setRotation(R);
                    dir = 2;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
         }
         else if(getX() == 336 & getY() == 208)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(R);
                    dir = 2;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }
            }
            else if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(D);
                    dir = 3;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
         }
         else if(getX() == 368 & getY() == 208)
         {
            if(dir == 3)
            {
                setRotation(L);
                dir = 4;
            }
            else if(dir == 2)
            {
                setRotation(U);
                dir = 1;
            }
         }
         else if(getX() == 128 & getY() == 272)
         {
            if(dir == 3)
            {
                setRotation(R);
                dir = 2;
            }
            else if(dir == 4)
            {
                setRotation(U);
                dir = 1;
            }
         }
         else if(getX() == 272 & getY() == 272)
         {
            if(dir == 3)
            {
                setRotation(L);
                dir = 4;
            }
            else if(dir == 2)
            {
                setRotation(U);
                dir = 1;
            }
         }
         else if(getX() == 200 & getY() == 272)
         {
            if(dir == 1)
            {
                if(rnd == 0)
                {
                    setRotation(R);
                    dir = 2;
                }
                else if(rnd == 1)
                {
                    setRotation(L);
                    dir = 4;
                }
            }
            else if(dir == 2)
            {
                if(rnd == 0)
                {
                    setRotation(D);
                    dir = 3;
                }
                else if(rnd == 1)
                {
                    setRotation(R);
                    dir = 2;
                }
            }
            else if(dir == 4)
            {
                if(rnd == 0)
                {
                    setRotation(L);
                    dir = 4;
                }
                else if(rnd == 1)
                {
                    setRotation(D);
                    dir = 3;
                }
            }
         }
    }
    public void botCX()
    {
    int rnd = Greenfoot.getRandomNumber(2);
     if(getX() == 32 & getY() == 336)
     {
        if(dir == 1)
        {
                setRotation(R);
                dir = 2;
        }
        else if(dir == 4)
        {
                setRotation(D);
                dir = 3;
        }
    }
     else if(getX() == 64 & getY() == 336)
     {
        if(dir == 3)
        {
            if(rnd == 0)
            {
                setRotation(R);
                dir = 2;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
        else if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
    }
    else if(getX() == 112 & getY() == 336)
     {
        if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(D);
                dir = 3;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
        else if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(D);
                dir = 3;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 1)
        {
            if(rnd == 0)
            {
                setRotation(L);
                dir = 4;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
     }
     else if(getX() == 200 & getY() == 336)
     {
        if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
        else if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 3)
        {
            if(rnd == 0)
            {
                setRotation(L);
                dir = 4;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
     }
     else if(getX() == 288 & getY() == 336)
     {
        if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(D);
                dir = 3;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
        else if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(D);
                dir = 3;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 1)
        {
            if(rnd == 0)
            {
                setRotation(L);
                dir = 4;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
     }
     else if(getX() == 336 & getY() == 336)
     {
        if(dir == 3)
        {
            if(rnd == 0)
            {
                setRotation(R);
                dir = 2;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
        else if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
    }
    else if(getX() == 368 & getY() == 336)
     {
        if(dir == 1)
        {
                setRotation(R);
                dir = 2;
        }
        else if(dir == 2)
        {
                setRotation(D);
                dir = 3;
        }
    }
    else if(getX() == 32 & getY() == 400)
    {
        if(dir == 1)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 3)
        {
            if(rnd == 0)
            {
                setRotation(D);
                dir = 3;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        else if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(D);
                dir = 3;
            }
        }
     }
    }
    else if(getX() == 368 & getY() == 400)
    {
        if(dir == 1)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
        else if(dir == 3)
        {
            if(rnd == 0)
            {
                setRotation(D);
                dir = 3;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        else if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(D);
                dir = 3;
            }
        }
     }
    }
    else if(getX() == 112 & getY() == 464)
     {
        if(dir == 4)
        {
                setRotation(U);
                dir = 1;
        }
        else if(dir == 3)
        {
                setRotation(R);
                dir = 2;
        }
    }
    else if(getX() == 288 & getY() == 464)
     {
        if(dir == 2)
        {
                setRotation(U);
                dir = 1;
        }
        else if(dir == 3)
        {
                setRotation(L);
                dir = 4;
        }
    }
    else if(getX() == 32 & getY() == 536)
     {
        if(dir == 4)
        {
                setRotation(U);
                dir = 1;
        }
        else if(dir == 3)
        {
                setRotation(R);
                dir = 2;
        }
    }
    else if(getX() == 368 & getY() == 536)
     {
        if(dir == 2)
        {
                setRotation(U);
                dir = 1;
        }
        else if(dir == 3)
        {
                setRotation(L);
                dir = 4;
        }
    }
    else if(getX() == 168 & getY() == 536)
    {
        if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 3)
        {
            if(rnd == 0)
            {
                setRotation(R);
                dir = 2;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        else if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
       }
     }
     else if(getX() == 232 & getY() == 536)
    {
        if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 3)
        {
            if(rnd == 0)
            {
                setRotation(R);
                dir = 2;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        else if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
       }
     }
     else if(getX() == 168 & getY() == 464)
    {
        if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(D);
                dir = 3;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 1)
        {
            if(rnd == 0)
            {
                setRotation(R);
                dir = 2;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        else if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(D);
                dir = 3;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
       }
     }
     else if(getX() == 232 & getY() == 464)
    {
        if(dir == 2)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(R);
                dir = 2;
            }
        }
        else if(dir == 1)
        {
            if(rnd == 0)
            {
                setRotation(R);
                dir = 2;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        else if(dir == 4)
        {
            if(rnd == 0)
            {
                setRotation(U);
                dir = 1;
            }
            else if(rnd == 1)
            {
                setRotation(L);
                dir = 4;
            }
        }
       }
     }
  } 
}
