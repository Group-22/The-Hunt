import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Forest extends World
{
    public Forest()
    {    
        super(400, 560, 1); 
        placeBushes();
    }
    public void placeBushes()
    {
        placeOther();
        placeBot();
        placePer();
        placeTop();
        placeMid();
    }
    public void placeOther()
    {
        addObject(new House(), 200, 160);
        addObject(new Hole(), 96, 72);
        addObject(new Hole(), 305, 72);
        addObject(new Hole(), 200, 528);
    }
    //Bellow we establish where to place bushes in seperate sections
    public void placePer()
    {
        for (int i = 0; i <= 400; i = i + 16)
        {
            addObject(new Bush(), i, 0);
        }
        for (int ii = 0; ii <= 400; ii = ii + 16)
        {
            addObject(new Bush(), ii, 560);
        }
        for (int j = 0; j <= 560; j = j + 16)
        {
            addObject(new Bush(), 0, j);
        }
        for (int jj = 0; jj <= 560; jj = jj + 16)
        {
            addObject(new Bush(), 400, jj);
        }
    }
    public void placeTop()
    {
        //Middle bushes
        for (int T = 0; T <= 80; T = T + 16)
        {
            addObject(new Bush(), 200, T);
        }    
        for (int TT = 0; TT <= 80 ; TT = TT + 16)
        {
            addObject(new Bush(), 201, TT);
        }
        //Left bushes
        addObject(new Bush(), 64, 64);
        addObject(new Bush(), 128, 64);
        addObject(new Bush(), 64, 80);
        addObject(new Bush(), 128, 80);
        //Right bushes
        addObject(new Bush(), 273, 64);
        addObject(new Bush(), 336, 64);
        addObject(new Bush(), 273, 80);
        addObject(new Bush(), 336, 80);
    }
    public void placeMid()
    {
        for(int MTLL = 144; MTLL <= 240; MTLL = MTLL + 16 )
        {
            for (int MTL = 64; MTL <= 96 ; MTL = MTL + 16)
            {
                addObject(new Bush(), MTL , MTLL);
            }
        }
        for(int MTRR = 144; MTRR <= 240; MTRR = MTRR + 16 )
        {
            for (int MTR = 304; MTR <= 336 ; MTR = MTR + 16)
            {
                addObject(new Bush(), MTR , MTRR);
            }
        }
        for (int MH = 168; MH <= 232 ; MH = MH + 16)
        {
            addObject(new Bush(), MH , 240);
        } 
    }
    public void placeBot()
    {
        //Middle bushes
        for (int B = 480; B <= 496 ; B = B + 16)
        {
            addObject(new Bush(), 200, B);
        }    
        for (int BB = 480; BB <= 496 ; BB = BB + 16)
        {
            addObject(new Bush(), 201, BB);
        } 
        for (int TM = 152; TM <= 256 ; TM = TM + 16)
        {
            addObject(new Bush(), TM , 416);
        }   
        //Left bushes
        for (int TRB = 64; TRB <= 80 ; TRB = TRB + 16)
        {
            addObject(new Bush(), TRB , 416);
        } 
        for (int TRB = 64; TRB <= 80 ; TRB = TRB + 16)
        {
            addObject(new Bush(), TRB , 432);
        } 
        for (int TRB = 64; TRB <= 80 ; TRB = TRB + 16)
        {
            addObject(new Bush(), TRB , 448);
        } 
        for (int TRB = 64; TRB <= 80 ; TRB = TRB + 16)
        {
            addObject(new Bush(), TRB , 464);
        } 
                for (int BL = 64; BL <= 136 ; BL = BL + 16)
        {
            addObject(new Bush(), BL , 480);
        }
        for (int BLL = 64; BLL <= 136 ; BLL = BLL + 16)
        {
            addObject(new Bush(), BLL , 496);
        } 
        //Right bushes
        for (int TRB = 320; TRB <= 336 ; TRB = TRB + 16)
        {
            addObject(new Bush(), TRB , 416);
        }
        for (int TRB = 320; TRB <= 336 ; TRB = TRB + 16)
        {
            addObject(new Bush(), TRB , 432);
        }   
        for (int TRB = 320; TRB <= 336 ; TRB = TRB + 16)
        {
            addObject(new Bush(), TRB , 448);
        }   
        for (int TRB = 320; TRB <= 336 ; TRB = TRB + 16)
        {
            addObject(new Bush(), TRB , 464);
        }   
        for (int BR = 336; BR >= 265 ; BR = BR - 16)
        {
            addObject(new Bush(), BR , 480);
        }
        for (int BRR = 336; BRR >= 265 ; BRR = BRR - 16)
        {
            addObject(new Bush(), BRR , 496);
        }    
    }
}
